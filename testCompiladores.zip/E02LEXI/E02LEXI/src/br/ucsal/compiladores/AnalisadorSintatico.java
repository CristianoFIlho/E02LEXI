package br.ucsal.compiladores;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Scanner;

public class AnalisadorSintatico {
	private static String fileName;
	private static Scanner scanner = new Scanner(System.in);
	private static File file;
	
	public static void main(String[] args) {
		try {
			System.out.println("Insira o nome do arquivo");
			fileName = scanner.next();
			
			if (!fileName.contains(".201")) {
				System.out.println("insira o nome do arquivo sem a");
				return;
			}
			
			file = new File(fileName + ".201");
			
			AnalisadorLexico lexico = new AnalisadorLexico(new BufferedReader(new FileReader(file)));
			RelatorioLexico relatorioLexico = lexico.gerarRelatorio();
			gerarRelatorioLexico(relatorioLexico);
			gerarTabelaDeSimbolos(relatorioLexico.getTabeladeSimbolos());
			
			
		} catch (Exception e) {
			System.out.println("Ocorreu um erro ao abrir o arquivo");
			e.printStackTrace();
		}
	}
	
	public static void gerarRelatorioLexico(RelatorioLexico relatorioLexico) throws IOException {
	
		OutputStream os = new FileOutputStream(fileName + ".LEX"); 
        Writer wr = new OutputStreamWriter(os); 
        BufferedWriter br = new BufferedWriter(wr);
		
		System.out.println("Output Lexico");
		System.out.println("atomos " + relatorioLexico.getItens().size());
		
		br.write("Equipe E02  ");
		br.newLine();
		br.write("Equipe: ");
		br.newLine();
		br.write("Cristiano Filho, cristiano.filho@ucsal.edu.br, (71) 983973644");
		br.newLine();
		br.write("Enzo Santana., enzo.almeida@ucsal.edu.br , (71) 991150087");
		br.newLine();
		br.write("Vinicius dos Santos., vinicius.candeias@ucsal.edu.br, (71) 984353370");
		br.newLine();
		br.write("Rodrigo Fiuza., rodrigo.oliveira@ucsal.edu.br, (71) 981086001");
		
		
	
		
		
		for (int i = 0; i < relatorioLexico.getItens().size(); i++) {
			br.write(relatorioLexico.getItens().get(i).toStringLex());
			br.newLine();
		}
		
		br.close();
		
	}
	
	public static void gerarTabelaDeSimbolos(TabeladeSimbolos simbolos) throws IOException {
		File tabSimbolos = new File(fileName + ".TAB");
		FileWriter fileWriter = new FileWriter(tabSimbolos);
		
		fileWriter.append(simbolos.toString());
		
		fileWriter.close();
	}
	
	

}
