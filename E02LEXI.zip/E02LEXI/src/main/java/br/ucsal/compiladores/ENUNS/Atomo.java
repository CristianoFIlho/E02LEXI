package br.ucsal.compiladores.ENUNS;

public enum Atomo {
		CADEIA("cadeia", "101"),
		INTEIRO("inteiro", "108"),
		PORCENTAGEM("%", "301"),
		MENOS("-", "401"),
		CONS_CADEIA("cons-cadeia", "501"),
		SUBMAQUINA1("submáquina1", "601"),
		CARACTER("caracter", "102"),
		LOGICO("logico", "109"),
		ABRE_PARENTESES("(", "302"),
		MULTIPLICA("*", "402"),
		CONS_CARACTER("cons-caracter", "502"),
		SUBMAQUINA2("submáquina2", "602"),
		DECLARACOES("declaracoes", "103"),
		PAUSA("pausa", "110"),
		FECHA_PARENTESES(")", "303"),
		BARRA("/", "403"),
		CONS_INTEIRO("cons-inteiro", "503"),
		SUBMAQUINA3("submáquina3", "603"),
		ENQUANTO("enquanto", "104"),
		PROGRAMA("programa", "111"),
		VIRGULA(",", "304"),
		MAIS("+", "404"),
		CONS_REAL("cons-real", "504"),
		FALSE("false", "201"),
		REAL("real", "112"),
		DOIS_PONTOS(":", "305"),
		DIFERENTE("!=","411"),
		NOM_FUNCAO("nom-funcao", "511"),
		SUBMAQUINAN("submáquinan", "60n"),
		FIM_DECLARACOES("fim-declaracoes", "202"),
		RETORNA("retorna", "113"),
		DE(":=", "306"),
		DIFERENTE2("#", "411"),
		NOM_PROGRAMA("nom-programa", "512"),
		FIM_ENQUANTO("fim-enquanto", "203"),
		SE("se", "114"),
		PONTO_VIRGULA(";", "307"),
		MENOR("<", "412"),
		VARIAVEL("variavel", "513"),
		FIM_FUNC("fim-func", "204"),
		SENAO("senao", "115"),
		INTERROGACAO("?", "308"),
		MENOR_IGUAL("<=", "413"),
		FIM_FUNCOES("fim-funcoes", "205"),
		TIPO_FUNC("tipo-func", "116"),
		ABRE_COLCHETE("[", "309"),
		IGUAL_IGUAL("==", "414"),
		FIM_PROGRAMA("fim-programa", "206"),
		TIPO_PARAM("tipo-param", "117"),
		FECHA_COLCHETE("]", "310"),
		MAIOR(">", "415"),
		FIM_SE("fim-se", "105"),
		TIPO_VAR("tipo-var", "118"),
		ABRE_CHAVE("{", "311"),
		MAIOR_IGUAL(">=", "416"),
		FUNCOES("funcoes", "106"),
		TRUE("true", "119"),
		FECHA_CHAVE("}", "312"),
		IMPRIME("imprime", "107"),
		VAZIO("vazio", "120");

	private String atomo;
	
	private Integer tamanhoDoAtomo;
	
	private String codigo;
	
	private String lexeme;
	
	private Integer indiceTabSimbolos;

	Atomo(String atomo, String codigo) {
		this.atomo = atomo;
		this.codigo = codigo;
		lexeme = null;
		tamanhoDoAtomo = null;
	}
	
	Atomo(String atomo, String codigo, String conteudo, Integer tamanho, Integer linha, Integer posLinha, Integer indiceTabSimbolos) {
		this.atomo = atomo;
		this.codigo = codigo;
		this.lexeme = conteudo;
		Integer tamanhoFinal = tamanho;
		if (tamanhoFinal > 30) {
			tamanhoFinal = 30;
		}
		this.tamanhoDoAtomo = tamanhoFinal;
		
		this.indiceTabSimbolos = indiceTabSimbolos;
	}
	
	public String getAtomo() {
		return this.atomo;
	}
	
	public String getCodigo() {
		return this.codigo;
	}
	
	public void setLexeme(String conteudo) {
		this.lexeme = conteudo;
	}
	
	public String getLexeme() {
		return this.lexeme;
	}
	
	public void setTamanho(Integer tamanho) {
		Integer tamanhoFinal = tamanho;
		if (tamanhoFinal > 30) {
			tamanhoFinal = 30;
		}
		this.tamanhoDoAtomo = tamanhoFinal;
	}
	

	
	public Integer getTamanho() {
		return this.tamanhoDoAtomo;
	}
	
	public Integer getIndiceTabSimbolos() {
		return this.indiceTabSimbolos;
	}
	
	public void setIndiceTabSimbolos(Integer indiceTabSimbolos) {
		this.indiceTabSimbolos = indiceTabSimbolos;
	}
	
	public static Atomo parsePalavraReservada(String text) {
		for (Atomo palavraReservada : values()) {
		      if (palavraReservada.getAtomo() != null && 
		        palavraReservada.getAtomo().equalsIgnoreCase(text))
		        return palavraReservada; 
		    } 
		    return null;
	}
	
	@Override
	public String toString() {
		String lexeme = this.getAtomo() == null ? "null" : this.getAtomo();
		String conteudo = this.getLexeme() == null ? "null" : this.getLexeme();
		String codAtomo = this.getCodigo() == null ? "null" : this.getCodigo();
		String indice = this.getIndiceTabSimbolos() == null ? "null" : this.getIndiceTabSimbolos().toString();
		return "Lexeme: " + lexeme + ", conteudo: " + conteudo + ", codigo: " + codAtomo + ", tabela de simbolos: " + indice;
	}
}
