# Instruções para execução do StaticChecker
 

- No diretorio do projeto adicione o seu arquivo para executar o arquivo final, só
rodar a classe AnalisadorSintatico.java e obter o relatorio .LEX e .TAB;

- No console, digite o nome do  ̈seu arquivo ̈ Exemplo:  ̈test ̈ que você quer segue
imagem;

- Para executar o StaticChekerE02-2.7.3-jar no terminal digite (java -jar
StaticChekerE02-2.7.3-jar)

![teste2](https://user-images.githubusercontent.com/54041918/212396160-cfdc646d-41a7-42cf-a76d-1202fa735e75.png)

![test](https://user-images.githubusercontent.com/54041918/212396220-b2f599ee-b33c-4c69-a3d6-17399deeb018.png)
