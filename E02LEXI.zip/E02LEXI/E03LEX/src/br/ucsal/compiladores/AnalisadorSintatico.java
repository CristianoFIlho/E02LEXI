package br.ucsal.compiladores;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Scanner;

public class AnalisadorSintatico {
	private static String fileName;
	private static Scanner scanner = new Scanner(System.in);
	private static File file;
	
	public static void main(String[] args) {
		try {
			System.out.println("Insira o nome do arquivo");
			fileName = scanner.next();
			
			if (fileName.contains(".201")) {
				System.out.println("insira o nome do arquivo sem a");
				return;
			}
			
			file = new File(fileName + ".201");
			
			AnalisadorLexico lexico = new AnalisadorLexico(new BufferedReader(new FileReader(file)));
			RelatorioLexico relatorioLexico = lexico.gerarRelatorio();
			gerarRelatorioLexico(relatorioLexico);
			gerarTabelaDeSimbolos(relatorioLexico.getTabeladeSimbolos());
			
			
		} catch (Exception e) {
			System.out.println("Ocorreu um erro ao abrir o arquivo");
			e.printStackTrace();
		}
	}
	
	public static void gerarRelatorioLexico(RelatorioLexico relatorioLexico) throws IOException {
		//File relatorioLex = new File("./" + fileName + ".LEX");
		//System.out.println("test");
		OutputStream os = new FileOutputStream(fileName + ".LEX"); // nome do arquivo que será escrito
        Writer wr = new OutputStreamWriter(os); // criação de um escritor
        BufferedWriter br = new BufferedWriter(wr);
		//FileWriter fileWriter = new FileWriter(relatorioLex);
		System.out.println("Output Lexico");
		System.out.println("atomos " + relatorioLexico.getItens().size());
		
		br.write("Equipe E02  ");
		br.newLine();
		br.write("Equipe: ");
		br.newLine();
		br.write("Cristiano Filho, cristiano.filho@ucsal.edu.br, (71) 983973644");
		br.newLine();
		br.write("Enzo Santana., enzo.almeida@ucsal.edu.br , (71) 991150087");
		br.newLine();
		br.write("Vinicius dos Santos., vinicius.candeias@ucsal.edu.br, (71) 984353370");
		br.newLine();
		br.write("Rodrigo Fiuza., rodrigo.oliveira@ucsal.edu.br, (71) 981086001");
		
		
	
		
		
		for (int i = 0; i < relatorioLexico.getItens().size(); i++) {
			br.write(relatorioLexico.getItens().get(i).toStringLex());
			br.newLine();
		}
		
		br.close();
		
	}
	
	public static void gerarTabelaDeSimbolos(TabeladeSimbolos simbolos) throws IOException {
		File tabSimbolos = new File(fileName + ".TAB");
		FileWriter fileWriter = new FileWriter(tabSimbolos);
		
		fileWriter.append(simbolos.toString());
		
		fileWriter.close();
	}
	
	/**
	 * Arquivo .LEX
	 * deve mostrar a rela��o dos s�mbolos da linguagem que foram encontrados no texto fonte analisado, 
	 * na ordem em que estes aparecerem e tantas vezes quantas tenham aparecido.
	 * 
	 * deve indicar no cabe�alho: o c�digo identificador da equipe, os nomes, e-mails e telefones 
	 * de todos os componentes da equipe que participaram da elabora��o desta etapa do projeto.
	 * 
	 * Para cada linha detalhe do relat�rio de an�lise l�xica, devem ser exibidas no m�nimo as informa��es: 
	 * o elemento l�xico formado (chamado de lexeme), o c�digo do �tomo correspondente a este elemento l�xico 
	 * e o �ndice deste s�mbolo na tabela de s�mbolos (quando for um s�mbolo que seja armazenado nesta estrutura de dados).
	 * 
	 * 
	 * 
	 * 
	 * Arquivo .TAB
	 * deve mostrar todos os s�mbolos do tipo identificadores que foram armazenados na tabela de s�mbolos durante o processo de avalia��o do texto fonte.
	 * 
	 * Para cada s�mbolo armazenado na tabela de s�mbolos devem ser relacionados 
	 * todos os atributos dele com todos os valores que foram preenchidos durante o funcionamento do Static Checker
	 */

}
